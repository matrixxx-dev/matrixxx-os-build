- <https://wiki.debian.org/fstab>

********************************************************************************
# fstab:

Die Datei fstab (/etc/fstab) (oder Dateisystemtabelle) ist eine
Systemkonfigurationsdatei auf Debian -Systemen. In der FSTAB -Datei werden
in der Regel alle verfügbaren Datenträger und Festplattenpartitionen aufgeführt
und gibt an, wie sie initialisiert oder auf andere Weise in das Dateisystem
des Gesamtsystems integriert werden sollen.

- "file system" - Definiert das Speichergerät (z.B. /dev/sda1).

- "dir" - teilt dem Befehl 'mount' mit, wohin das  "file system" zu mounten ist.

- "type" - Definiert den Dateisystemtyp des Geräts oder der Partition,
  die gemountet werden soll.
  - Beispiele sind:
    ext2, ext3, reiserfs, xfs, jfs, smbfs, iso9660, vfat, ntfs, swap und auto.
    Mit dem Typ 'auto' versucht das System zu erraten, welche Art von
    Dateisystem das Speichergerät enthält.
    (nützlich für 'removable' Geräte)

- "options" - Definieren Sie bestimmte Optionen für Dateisysteme.
  Einige Optionen beziehen sich nur auf das Dateisystem selbst.
  - Einige der häufigsten Optionen sind:
    - auto - Dateisystem automatisch beim Bootvorgang mounten oder wenn der
      Befehl 'mount -a' ausgeführt wird.
    - noauto - Das Dateisystem wird nur gemountet, wenn Sie es sagen.
    - exec - Erlauben des Ausführen von Binärdateien auf dem "file system"
      (Standard).
    - noexec - Verbieten des Ausführen von Binärdateien auf dem "file system"
    - ro - mounten des "file system" im read only Modus.
    - rw - mounten des "file system" im read-write Modus.
    - sync - I/O sollte synchron erfolgen.
    - async - I/O sollte asynchron erfolgen.
    - flush - Spezifische Option für FAT
    - user - Erlauben Sie jedem Benutzer, das Dateisystem zu mounten
     (impliziert noexec,nosuid,nodev sofern nicht überschrieben)
    - nouser - Erlauben Sie nur Root, das Dateisystem zu mounten (Standard).
    - defaults - Standard-Mount-Einstellungen
      (gleichwertig zu rw,suid,dev,exec,auto,nouser,async).
    - suid - Ermöglichen Sie Operationen mit SUID- und SGID-Bits.
    - nosuid - Blockieren Sie Operationen mit SUID- und SGID-Bits.
    - noatime - Aktualisieren Sie die Inode-Zugriffszeiten nicht im Dateisystem.
    - nodiratime - Aktualisieren Sie den Inode-Zugriffszeiten für ein Verzeichnis
      nicht im Dateisystem. (implizit bei noatime Aktivierung)
    - relatime - Aktualisieren Sie die Inode-Zugriffszeiten relativ zu
      Änderungszeit
- "dump" - wird vom Dump-Dienstprogramm verwendet, um zu entscheiden,
  wann eine Sicherung erstellt werden soll. Mögliche Einträge sind 0 und 1.
  Wenn 0, ignoriert Dump das Dateisystem, falls 1 Dump eine Sicherung erstellt.
  (Die meisten Benutzer haben Dump nicht installiert, daher sollten 0 für
  "dump" gesetzt werden.
- "pass" - FSCK liest den "pass"-Wert und bestimmt, in welcher Reihenfolge
   die Dateisysteme überprüft werden sollten.
   Mögliche Einträge sind 0, 1 und 2.
   Das Stammdateisystem sollte die höchste Priorität haben.
   1 alle anderen Dateisysteme, die Sie vom FSCK -Dienstprogramm überprüft
   haben möchten das







