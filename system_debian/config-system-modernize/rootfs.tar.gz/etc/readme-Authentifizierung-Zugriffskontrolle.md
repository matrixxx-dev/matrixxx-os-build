********************************************************************************
# Wichtige Konfigurationsdateien:

Datei        Berechtigung Benutzer Gruppe Beschreibung
------------ ------------ -------- ------ --------------------------------------
/etc/passwd  -rw-r--r--   root     root   (bereinigte) Informationen zum Benutzerkonto
/etc/shadow  -rw-r-----   root     shadow geschützte Informationen zum Benutzerkonto
/etc/group   -rw-r--r--   root     root   Informationen zur Gruppe
/etc/gshadow -rw-r-----   root     shadow geschützte Informationen zur Gruppe
/etc/sudoers -r--r-----   root     root   sudo security policy

****************************************
### /etc/passwd - User account information:
<https://man7.org/linux/man-pages/man5/passwd.5@@shadow-utils.html>

Beispiel: user1:x:1000:1000:User1 Name,,,:/home/user1:/bin/bash

- Benutzername (Login-Name):
  - (leer) Konto ohne Passwort
  - x      verschlüsseltes Passwort in "/etc/shadow"
- Eintrag zur Passwortspezifikation:
- nummerische Benutzer-ID:
- nummerische Gruppen-ID:
- Name oder Kommentarfeld:
- Home-Verzeichnis des Benutzers:
- optionale Angabe des Befehlsinterpreters für den Benutzer

****************************************
### /etc/shadow - Secure user account information:
<https://man7.org/linux/man-pages/man5/shadow.5@@shadow-utils.html>

Beispiel: user1:$1$Xop0FYH9$IfxyQwBe9b8tiyIkt2P4F/:13262:0:99999:7:::

- Benutzername (Login-Name):
- verschlüsseltes Passwort:
  - "*" steht für "kein Login"
  - $type$salt$hashed format
  - $1$   MD5
  - $2a$  Blowfish
  - $2y$  Eksblowfish
  - $5$   SHA-256
  - $6$   SHA-512
  - $y$   yescrypt (or $7$)
    - is a password-based key derivation function (KDF)
      and password hashing scheme
- Datum der letzten Passwortänderung, ausgedrückt als Anzahl der Tage
  seit dem 1. Januar 1970:
- Anzahl der Tage, die der Benutzer vor der erneuten Änderung des Passworts
  warten muss:
- Anzahl der Tage, nach denen der Benutzer das Passwort ändern muss:
- Anzahl der Tage vor dem Verfall des Passworts, während derer der Benutzer
  vor dem Passwortverfall gewarnt wird:
- Anzahl der Tage, während derer das Passwort noch akzeptiert wird, obwohl es
  abgelaufen ist:
- Datum, an dem das Konto abläuft, ausgedrückt als Anzahl der Tage
  seit dem 1. Januar 1970

### /etc/shadow- - Backup file for /etc/shadow
Note: this file is used by the tools of the shadow toolsuite,
      but not by all user and password management tools.

****************************************
### /etc/group              user group file:
<https://man7.org/linux/man-pages/man5/group.5.html>

Beispiel: group1:x:20:user1,user2

- Gruppenname:
- verschlüsseltes Passwort:
  - (nicht wirklich benutzt)
- nummerische Gruppen-ID:
- Liste von Benutzernamen getrennte durch ","

****************************************
### /etc/gshadow - Secure group account information
<https://man7.org/linux/man-pages/man5/gshadow.5@@shadow-utils.html>

********************************************************************************
### /etc/sudoers - default sudo security policy plugin
<https://man7.org/linux/man-pages/man5/sudoers.5.html>

Die **"User privilege specification"** ist der Teil dieser Datei in dem
festgelegt ist wer was ausführen darf

********************************************************************************
