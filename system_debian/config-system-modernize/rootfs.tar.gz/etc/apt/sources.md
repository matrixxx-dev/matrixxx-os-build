
## ########################################################################## ##
# Debian (20.10.2025)
# ------- -------- ------------ ---------- ----------- ------- ----- -----------
# Version Name     Status       Release    Support-End Kernel        x86
# ------- -------- ------------ ---------- ----------- ------- ----- -----------
# 10      Buster                2019-07-06 2024-06-30  4.19.37 (LTS) amd64 i386
# 11      Bullseye oldoldstable 2021-08-14 2026-08-31  5.10    (LTS) amd64 i386
# 12      Bookworm oldstable    2023-06-10 2028-06-30  6.1     (LTS) amd64 i386
# 13      Trixie   stable       2025-08-09             6.12    (LTS) amd64
# 14      Forky    testing
# 15      Duke
# ------- -------- ------------ ---------- ----------- ------- ----- -----------
# possible extra-suites:
# - stable testing unstable(=sid) experimental
# possible software categories:
# - main contrib non-free non-free-firmware
# [contrib, non-free and non-free-firmware are not conform to
# Debian Free Software Guidelines (DFSG)]
## ########################################################################## ##

