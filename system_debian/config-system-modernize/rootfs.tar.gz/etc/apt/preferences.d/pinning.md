## Installation Unstable

```
Testing wird verwendet und [pakage] soll aus aus Unstable installiert werden.
Es gibt grundsätzlich zwei Methoden für die Installation:

  apt-get install enlightenment/unstable
oder
  apt-get -t unstable install enlightenment

Das erste Beispiel wird nicht versuchen irgendwelche Pakete auf Ihrem System
zu aktualisieren; wenn bestimmte Abhängigkeiten verletzt werden, schlägt die
Installation fehl.

Die zweite Methode wird versuchen, jegliche Abhängigkeiten zu
aktualisieren/installieren. Bei der obigen Prozedur wird Sie 'apt-get'
natürlich vor dem Fortfahren fragen.

```

********************************************************************************
## Parameter für Pinning
Folgende Parameter können für das Pinnen mittels release verwendet werden:

- a (archive) - Der Name eines Repositories
- c (components) - Der Bereich eines Repositories
- v (version) - Version des Repositories bzw. der Veröffentlichung
- o (origin) - Die "Erzeuger" des Repositories z.B. debian
  - Nicht zu Verwechseln mit origin als Quelle (Domainname).
- l (label) - Name der Distribution

examples:
- release v=12.5,o=Debian,a=stable,n=bookworm,l=Debian,c=main,b=i386
- release v=12.5,o=Debian,a=stable,n=bookworm,l=Debian,c=main,b=amd64
- release v=12.5,o=Debian,a=stable,n=bookworm,l=Debian,c=contrib,b=i386
- release v=12.5,o=Debian,a=stable,n=bookworm,l=Debian,c=non-free,b=i386
- usw.

Die genauen Werte können mittels des Befehls **apt-cache policy** nachgeschlagen
werden.

## Werte für Pin-Priority
- größer 999:
  - Version wird in jedem Fall installiert, auch wenn das einen **Downgrade**
    des Paketes nach sich zieht
- von 990 bis 999:
  - Version wird installiert, auch wenn sie nicht zum Release gehört, es sei
    denn ein aktuelleres Pakete ist bereits installiert
- von 500 bis 989:
  - Version wird installiert, es sei denn, es gibt eine Version, die zum
    Release gehört oder eine aktuellere Version ist bereits installiert
- von 100 bis 499
  - Version wird installiert, es sei denn, es gibt eine aktuellere die nicht
    zum Release gehört oder die bereits installierte Version ist aktueller
- von 1 bis 99
  - Version wird nur dann installiert, wenn es keine bereits installierte gibt
- negativer Wert
  - Version wird nicht installiert


Das Paket mit der höchsten Punktzahl wird immer bevorzugt.

## Explizietes Pinning
- /etc/apt/preferences
- /etc/apt/preferences.d/*
  - naming convention: either no or "pref" as filename extension
  - **apt.conf.d:** see Dir::Ignore-Files-Silently configuration list

## Dateiendungen, die ignoriert werden:
- apt-config dump | grep -i ignore

********************************************************************************
## Paketstatus
```
Man kann eine derzeit installierte Paketversion mit
sudo apt-mark hold [pakage]
auf hold setzen, d.h., kommende aktuellere Versionen werden nicht installiert.

Sollen Updates wieder berücksichtigt werden, ist
sudo apt-mark unhold [pakage]
auszuführen.
```


